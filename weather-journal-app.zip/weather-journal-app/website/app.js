/* Global Variables */

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();

const apikey = '&appid=9b9f6e44e86d5be68c024bba31a1b971&units=metric';
const weatherappdataUrl ='http://api.openweathermap.org/data/2.5/weather?zip=';

  const generateFunction =() => {
  const zipCode= document.getElementById("zip").value;
  const feelings = document.getElementById("feelings").value;

  getData (zip).then((data) => {

  if(data){
    const{ main :{temp},
   } =data;

    const getInformation ={
      newDate ,
      temp:Math.round (temp) ,
       feelings,
    };


    postAlldata('/add', getInformation);
     }
    });
};

document.getElementById("generate").addEventListener("click", generateFunction);

const  getData= async (zip)=> {
  try{
    const res = await fetch( weatherappdataUrl + zip + apikey);
    const data = await res.json();

    if (data.cod != 300) {
      errorElement.innerHTML = data.message;
      setTimeout(() => errorElement.innerHTML = '', 3000);
      throw `${data.message}`;
  }
  return data;
}
    catch (error){
    console.log(error);
  }
};


     const postAlldata = async ( url = '', getInformation = {})=>{
      const response = await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
            
      body: JSON.stringify(getInformation), 
    });
  
      try {
        const newData = await response.json();
        console.log(newData);
        return newData;
      } 
      catch(error) {
      console.log("error", error);
      }
  };
 // postAlldata('/add', {answer:42});

  const update  = async() => {
    const response =  await fetch('/all');

    try
    { 
      const save = await response.json();

      document.getElementById("data").innerHTML= save.newData;
      document.getElementById("temp").innerHTML= save.temp;
      document.getElementById("content").innerHTML=save.content;
  }
  catch (error){
    console.log(error);
  }
  }


